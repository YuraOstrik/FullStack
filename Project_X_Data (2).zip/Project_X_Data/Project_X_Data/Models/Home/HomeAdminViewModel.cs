﻿using Project_X_Data.Data.Entities;

namespace Project_X_Data.Models.Home
{
    public class HomeAdminViewModel
    {
        //public IEnumerable<ProductGroup> ProductGroups { get; set; }
    }
}
