﻿using Project_X_Data.Data.Entities;

namespace Project_X_Data.Models.Home
{
    public class HomeCategoryViewModel
    {
        //public ProductGroup? ProductGroup { get; set; }
    }
}
